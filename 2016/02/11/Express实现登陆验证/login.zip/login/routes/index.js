var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', {msg:''});
});

//处理login数据
router.post('/login', function(req, res, next) {
  //如果没有post数据或者数据为空,直接返回
  if (req.body.uname == undefined || req.body.passwd == undefined ) {
    res.render('404', {});
    return;
  }
  if(req.body.uname == '' || req.body.passwd == '' ){
    res.render('index', {msg:'提示：用户名和密码不能为空！！'});
  }
  if(req.body.passwd != '12345'){
    res.render('index', {msg:'提示：密码错误！！'});
    return;
  }
  req.session.username = req.body.uname;
  res.redirect('/home');
});

//登陆后跳转显示用户名
router.get('/home', function(req, res, next) {
  if(req.session.username != undefined){//判断session是否存在
    res.render('home', {uname:req.session.username});
  }else{
    res.render('index', {msg:'提示：你还没有登陆！！'});
  }

});


module.exports = router;
