#include <iostream>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/core.hpp>
#include "ocr_decoder.h"
#include "histogram1d.h"

using namespace cv;
using namespace std;

int main(int argc, char* argv[])
{
	// if(argc != 2) {
 //        fprintf(stderr, "Usage: ./recognizer <image_filename>\n");
 //        return 1;
 //    }
    // Mat mat = imread(argv[1], 0);

    //按黑白读取图像
    Mat mat = imread("test1.jpg", 0);
    cv::imshow("initial_mat", mat);
    cv::waitKey(0);
    
    //画出直方图
    Histogram1D histogram1d;
    cv::imshow("histogram1d", histogram1d.getHistogramImage(mat));
    cv::waitKey(0);

    //阈值
    Mat threshold_mat;
    cv::threshold(mat, threshold_mat, 150, 255, cv::THRESH_BINARY);
    cv::imshow("threshold_mat", threshold_mat);
    cv::waitKey(0);

    //使用tesseract识别
    char buffer[255];
    OCRDecoder decoder;
    decoder.decodeGrayMat(threshold_mat, buffer);
    cout<<"result:"<<buffer<<endl;
}
