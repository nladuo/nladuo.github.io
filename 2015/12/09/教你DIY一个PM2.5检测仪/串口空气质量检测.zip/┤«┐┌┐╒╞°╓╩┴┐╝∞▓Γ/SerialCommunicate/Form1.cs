﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO.Ports;
namespace SerialCommunicate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived);      //串口数据接收事件
            serialPort1.Encoding = Encoding.GetEncoding("UTF-8");                                  //串口接收编码
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;                   //
        }

        private void button1_Click(object sender, EventArgs e)                                      //打开串口
        {
            try
            {
                serialPort1.PortName = comboBox1.Text;                                              //端口号
                serialPort1.BaudRate = Convert.ToInt32(comboBox2.Text);                             //波特率
                serialPort1.Open();                                                                 //打开串口
                button1.Enabled = false;
                button2.Enabled = true;
            }
            catch
            {
                MessageBox.Show("端口错误", "错误");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 1; i < 20; i++)
            {
                comboBox1.Items.Add("COM" + i.ToString());                                        //添加串口
            }
            comboBox1.Text = "COM1";                                                              //默认选项
            comboBox2.Text = "9600";
        }

        byte[] buffer = new byte[16]; //用于缓存字符 

        bool checkoutOneSequence(){
            return (buffer[0] == 0x42) && (buffer[1] == 0x4D) && (buffer[2] == 0x00) && (buffer[3] == 0x1C);
        }

        //序列左移
        private void shiftLeft(byte lastNum)
        {

            for (int i = 0; i < 15; i++)
            {
                buffer[i] = buffer[i + 1];
            }

            buffer[15] = lastNum;
        }

        //传感器是根据两个位显示pm2.5或者pm10的值的
        private int getIntValByTwoBytes(byte high, byte low)
        {
            int retVal = low;
            retVal += (int)(high) * 256;
            return retVal;
        }

        private void port_DataReceived(object sender, SerialDataReceivedEventArgs e)             
        {
            //string dataStr = serialPort1.ReadExisting();
            byte[] data = new byte[serialPort1.BytesToRead];                                //定义缓冲区，因为串口事件触发时有可能收到不止一个字节
            serialPort1.Read(data, 0, data.Length);
            foreach (byte Member in data)                                                   //遍历用法
            {
                shiftLeft(Member);
                string str = Convert.ToString(Member, 16).ToUpper();
                textBox1.AppendText("0x" + (str.Length == 1 ? "0" + str : str) + " ");
                if (checkoutOneSequence())
                {
                    cfpm1Label.Text = "PM1.0：" + getIntValByTwoBytes(buffer[4], buffer[5]) + "ug/m3";
                    cfpm25Label.Text = "PM2.5：" + getIntValByTwoBytes(buffer[6], buffer[7]) + "ug/m3";
                    cfpm10Label.Text = "PM10：" + getIntValByTwoBytes(buffer[8], buffer[9]) + "ug/m3";
                    gbpm1Label.Text = "PM1.0：" + getIntValByTwoBytes(buffer[10], buffer[11]) + "ug/m3";
                    gbpm25Label.Text = "PM2.5：" + getIntValByTwoBytes(buffer[12], buffer[13]) + "ug/m3";
                    gbpm10Label.Text = "PM10：" + getIntValByTwoBytes(buffer[14], buffer[15]) + "ug/m3";
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.Close();                                                            //关闭串口        
                button1.Enabled = true;
                button2.Enabled = false;
            }
            catch{ }
        }

    }
}
