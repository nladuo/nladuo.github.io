﻿namespace SerialCommunicate
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.端口 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pmLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cfpm1Label = new System.Windows.Forms.Label();
            this.cfpm25Label = new System.Windows.Forms.Label();
            this.cfpm10Label = new System.Windows.Forms.Label();
            this.gbpm1Label = new System.Windows.Forms.Label();
            this.gbpm25Label = new System.Windows.Forms.Label();
            this.gbpm10Label = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.ReadTimeout = 20;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.端口);
            this.groupBox1.Location = new System.Drawing.Point(12, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(183, 135);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "设置";
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(103, 100);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(74, 23);
            this.button2.TabIndex = 11;
            this.button2.Text = "关闭端口";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 100);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(74, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "打开端口";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteCustomSource.AddRange(new string[] {
            "600",
            "1200",
            "2400",
            "4800",
            "9600",
            "14400",
            "19200",
            "115200"});
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "600",
            "1200",
            "2400",
            "4800",
            "9600",
            "14400",
            "19200",
            "115200"});
            this.comboBox2.Location = new System.Drawing.Point(66, 60);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(111, 20);
            this.comboBox2.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "波特率";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(66, 20);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(111, 20);
            this.comboBox1.TabIndex = 1;
            // 
            // 端口
            // 
            this.端口.AutoSize = true;
            this.端口.Location = new System.Drawing.Point(6, 23);
            this.端口.Name = "端口";
            this.端口.Size = new System.Drawing.Size(29, 12);
            this.端口.TabIndex = 0;
            this.端口.Text = "端口";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox1.Location = new System.Drawing.Point(201, 12);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(323, 128);
            this.textBox1.TabIndex = 2;
            // 
            // pmLabel
            // 
            this.pmLabel.AutoSize = true;
            this.pmLabel.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pmLabel.Location = new System.Drawing.Point(16, 160);
            this.pmLabel.Name = "pmLabel";
            this.pmLabel.Size = new System.Drawing.Size(104, 19);
            this.pmLabel.TabIndex = 6;
            this.pmLabel.Text = "美国标准：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(271, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 19);
            this.label2.TabIndex = 7;
            this.label2.Text = "中国标准：";
            // 
            // cfpm1Label
            // 
            this.cfpm1Label.AutoSize = true;
            this.cfpm1Label.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cfpm1Label.Location = new System.Drawing.Point(18, 212);
            this.cfpm1Label.Name = "cfpm1Label";
            this.cfpm1Label.Size = new System.Drawing.Size(64, 16);
            this.cfpm1Label.TabIndex = 8;
            this.cfpm1Label.Text = "PM1.0：";
            // 
            // cfpm25Label
            // 
            this.cfpm25Label.AutoSize = true;
            this.cfpm25Label.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cfpm25Label.Location = new System.Drawing.Point(18, 256);
            this.cfpm25Label.Name = "cfpm25Label";
            this.cfpm25Label.Size = new System.Drawing.Size(64, 16);
            this.cfpm25Label.TabIndex = 9;
            this.cfpm25Label.Text = "PM2.5：";
            // 
            // cfpm10Label
            // 
            this.cfpm10Label.AutoSize = true;
            this.cfpm10Label.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cfpm10Label.Location = new System.Drawing.Point(18, 300);
            this.cfpm10Label.Name = "cfpm10Label";
            this.cfpm10Label.Size = new System.Drawing.Size(56, 16);
            this.cfpm10Label.TabIndex = 10;
            this.cfpm10Label.Text = "PM10：";
            // 
            // gbpm1Label
            // 
            this.gbpm1Label.AutoSize = true;
            this.gbpm1Label.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.gbpm1Label.Location = new System.Drawing.Point(272, 212);
            this.gbpm1Label.Name = "gbpm1Label";
            this.gbpm1Label.Size = new System.Drawing.Size(64, 16);
            this.gbpm1Label.TabIndex = 11;
            this.gbpm1Label.Text = "PM1.0：";
            // 
            // gbpm25Label
            // 
            this.gbpm25Label.AutoSize = true;
            this.gbpm25Label.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.gbpm25Label.Location = new System.Drawing.Point(272, 256);
            this.gbpm25Label.Name = "gbpm25Label";
            this.gbpm25Label.Size = new System.Drawing.Size(64, 16);
            this.gbpm25Label.TabIndex = 12;
            this.gbpm25Label.Text = "PM2.5：";
            // 
            // gbpm10Label
            // 
            this.gbpm10Label.AutoSize = true;
            this.gbpm10Label.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.gbpm10Label.Location = new System.Drawing.Point(272, 300);
            this.gbpm10Label.Name = "gbpm10Label";
            this.gbpm10Label.Size = new System.Drawing.Size(56, 16);
            this.gbpm10Label.TabIndex = 13;
            this.gbpm10Label.Text = "PM10：";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(536, 358);
            this.Controls.Add(this.gbpm10Label);
            this.Controls.Add(this.gbpm25Label);
            this.Controls.Add(this.gbpm1Label);
            this.Controls.Add(this.cfpm10Label);
            this.Controls.Add(this.cfpm25Label);
            this.Controls.Add(this.cfpm1Label);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pmLabel);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "空气污染指数检测";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label 端口;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label pmLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label cfpm1Label;
        private System.Windows.Forms.Label cfpm25Label;
        private System.Windows.Forms.Label cfpm10Label;
        private System.Windows.Forms.Label gbpm1Label;
        private System.Windows.Forms.Label gbpm25Label;
        private System.Windows.Forms.Label gbpm10Label;
    }
}

