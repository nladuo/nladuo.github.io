//
//  AppDelegate.h
//  BleCom
//
//  Created by TheMoonBird on 15/10/3.
//  Copyright (c) 2015年 KalenBlue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

