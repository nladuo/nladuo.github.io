//
//  main.m
//  BleCom
//
//  Created by TheMoonBird on 15/10/3.
//  Copyright (c) 2015年 KalenBlue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
